package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the impression database table.
 * 
 */
@Entity
@NamedQuery(name="Impression.findAll", query="SELECT i FROM Impression i")
@Table(name="impression")
public class Impression implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int impressionID;

	private String comment;

	private int pictureID;

	private int userID;

	public Impression() {
	}

	public int getImpressionID() {
		return this.impressionID;
	}

	public void setImpressionID(int impressionID) {
		this.impressionID = impressionID;
	}

	public String getComment() {
		return this.comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public int getPictureID() {
		return this.pictureID;
	}

	public void setPictureID(int pictureID) {
		this.pictureID = pictureID;
	}

	public int getUserID() {
		return this.userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

}