package model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the reply database table.
 * 
 */
@Entity
@NamedQuery(name="Reply.findAll", query="SELECT r FROM Reply r")
public class Reply implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int replyID;

	private int forumID;

	private String reply;

	private int userID;

	public Reply() {
	}

	public int getReplyID() {
		return this.replyID;
	}

	public void setReplyID(int replyID) {
		this.replyID = replyID;
	}

	public int getForumID() {
		return this.forumID;
	}

	public void setForumID(int forumID) {
		this.forumID = forumID;
	}

	public String getReply() {
		return this.reply;
	}

	public void setReply(String reply) {
		this.reply = reply;
	}

	public int getUserID() {
		return this.userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

}