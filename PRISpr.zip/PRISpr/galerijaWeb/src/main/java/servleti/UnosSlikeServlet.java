package servleti;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import managers.SlikaManager;
import model.Picture;
import model.User;

/**
 * Servlet implementation class UnosSlikeServlet
 */
public class UnosSlikeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UnosSlikeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String nazivS = request.getParameter("nazivSlike");
		String autorS = request.getParameter("autorSlike");
		String godinaS = request.getParameter("godinaSlike");
		String pravacS = request.getParameter("pravacSlike");
		int korisnikID = Integer.parseInt(request.getParameter("userID"));
		SlikaManager sm = new SlikaManager();
		String poruka;
		try
		{
			User korisnik = sm.getUserForID(korisnikID);
			Picture p = sm.saveSlika(nazivS, autorS, godinaS, pravacS, korisnik);
			
			if (p != null)
			{
				poruka = "Slika je uspesno sacuvana. ID slike je: " + p.getPictureID() + ", a ID korisnika je: " + korisnikID;
			}
			else
			{
				poruka = "Doslo je do greske, pokusajte ponovo";
			}
			request.setAttribute("poruka", poruka);
			RequestDispatcher rd = request.getServletContext().getRequestDispatcher("/UnosSlike.jsp");
			rd.forward(request, response);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

}
