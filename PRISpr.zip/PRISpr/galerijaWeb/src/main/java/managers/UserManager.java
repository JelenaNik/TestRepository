package managers;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import model.User;

public class UserManager {
		
	public boolean register(String name, String username, String password){
		try{
			EntityManager em = JPAUtils.getEntityManager();
			em.getTransaction().begin();
			User u = new User();
			u.setName(name); 
			u.setUsername(username);
			u.setPassword(password);
			em.persist(u);
			em.getTransaction().commit();
			em.close();
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	
	public int getUserID(User u){
		try{
			EntityManager em = JPAUtils.getEntityManager();
			int id = u.getUserID();
			em.close();
			return id;
		}catch(Exception e){
			e.printStackTrace();
			return 0;
		}
	}
}
