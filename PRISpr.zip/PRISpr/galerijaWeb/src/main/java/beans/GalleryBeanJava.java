
package beans;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

import model.User;

public class GalleryBeanJava {

	public boolean register(String name, String username, String password){
		try{
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("GalerijaJPA");
			EntityManager em = emf.createEntityManager();
			em.getTransaction().begin();
			User u = new User();
			u.setName(name); 
			u.setUsername(username);
			u.setPassword(password);
			em.persist(u);
			em.getTransaction().commit();
			em.close();
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	
	public static void main(String[] args){
		
	}
	
}
